// export all files in folder
module.exports.Account = require('./Account.js');
module.exports.Entry = require('./Entry.js');
module.exports.Competition = require('./Competition.js');
